const MongoClient = require('mongodb').MongoClient;
const assert = require('assert');

// documentaçÃo base
// https://github.com/mongodb/node-mongodb-native

// Connection URL
const url = 'mongodb://dev:tecs638form@ds151612.mlab.com:51612/academia-staging';

// Database Name
const dbName = 'academia-staging';

const de_para = {
    //moduleidOld - SubjectIdOld - QuestionIOldd - AnswerIdOld -> moduleidOld new - SubjectIdnew - QuestionIdnew - AnswerIdnew
    //["342423452345", 23452345234, 23452345, 234,5 23,4523452345, 3245]
}

// Use connect method to connect to the server
MongoClient.connect(url, function (err, client) {
    assert.equal(null, err);
    console.log("Connected successfully to server");

    const db = client.db(dbName);
    //console.log(db);

    const collection = db.collection('Users');
    // Find some documents
    collection.find({}).toArray(function (err, docs) {
        assert.equal(err, null);
        docs.forEach(function (val, index) {
            console.log(val.name + ' - ' + index);
            // Descomentar abaixo para fazer as alterações
            // collection.updateOne({
            //     _id: val._id
            // }, {
            //     $set: {
            //         name: 'Aluno ' + index
            //     }
            // }, function (err, result) {
            //     assert.equal(err, null);
            //     console.log(result.result.name);

            //     if (index === docs.length) {
            //         client.close();
            //     }
            // });
        });

    });

});